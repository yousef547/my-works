# vuejs-component-example

مثال عملي تابع لدورة الـ VueJs

الهدف منه توضيح أهمية الـ Components في vueJs

بإمكانك مشاهدة الدورة من هنا:

https://www.youtube.com/watch?v=b3bc8j5ERS0&list=PL1FWK-sgJ9ekBj_3Sv6RMz86Lxu61y0-l
